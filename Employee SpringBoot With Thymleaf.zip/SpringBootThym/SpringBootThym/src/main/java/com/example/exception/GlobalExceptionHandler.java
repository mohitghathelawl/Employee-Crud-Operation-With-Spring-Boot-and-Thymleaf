
package com.example.exception;

//import java.util.HashMap;
//import java.util.Map;

//import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler
{
	 @ExceptionHandler(MethodArgumentNotValidException.class)
	    public String handleValidationExceptions(MethodArgumentNotValidException ex, Model model) {
	        model.addAttribute("errors", ex.getBindingResult().getFieldErrors());
	        model.addAttribute("employee", ex.getBindingResult().getTarget());
	        return "employee-form";
	    }

	    @ExceptionHandler(Exception.class)
	    public String handleGeneralException(Exception ex, Model model) {
	        model.addAttribute("error", "An error occurred: " + ex.getMessage());
	        return "error";
	    }

}

