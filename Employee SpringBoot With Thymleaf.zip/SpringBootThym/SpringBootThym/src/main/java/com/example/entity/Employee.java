package com.example.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
public class Employee 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private Long id;
	
	@NotNull(message = "Name cannot be null")
	@Size(min = 2, max= 50, message= "Name must be between 2 to 50 character")
	private String name;
	
	@NotNull(message = "Designation cannot be null")
	@Size(min=2, max = 50, message= "Designation must be between 2 to 5 character")
	private String designation;
	
	@NotNull(message = "Salary cannot be null")
	private Double salary;
	
	//Default Constructor
	public Employee()
	{
		
	}
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public Employee(String Name, String Designation, Double Salary) 
	{
		this.name=Name;
		this.designation=Designation;
		this.salary=Salary;
	}
}
