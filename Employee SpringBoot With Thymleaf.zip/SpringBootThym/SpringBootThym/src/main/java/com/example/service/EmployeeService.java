package com.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.entity.Employee;
import com.example.repository.EmployeeRepository;

@Service
public class EmployeeService 
{
	private final EmployeeRepository employeeRepository; // interface ka ref
	
	public EmployeeService(EmployeeRepository employeeRepository) //Constructor for inilize object... 
	{
		this.employeeRepository = employeeRepository;
	}


	//Create or Update
	
	public Employee saveEmployee(Employee employee)
	{
		return employeeRepository.save(employee);
	}
	
	//Read by ID
	public Optional<Employee> getEmployee(Long id)
	{
		return employeeRepository.findById(id);
	}
	
	
	//Read All 
	public List<Employee> getAllEmployee()
	{
		return employeeRepository.findAll();
	}
	
	//Delete	
	public void deleteEmployee(Long id)
	{
		employeeRepository.deleteById(id);
	}
}

